import { createHighSchoolGame, newgrounds, prepareUrls, u, revoke } from "@dobuki/phaser-game";

export { createHighSchoolGame, newgrounds, prepareUrls, u, revoke };
