import { createGame, createHighSchoolGame } from "phaser-game";

export { createGame, createHighSchoolGame };
