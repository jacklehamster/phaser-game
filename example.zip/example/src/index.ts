import { createHighSchoolGame, newgrounds } from "phaser-game";

export { createHighSchoolGame, newgrounds };
